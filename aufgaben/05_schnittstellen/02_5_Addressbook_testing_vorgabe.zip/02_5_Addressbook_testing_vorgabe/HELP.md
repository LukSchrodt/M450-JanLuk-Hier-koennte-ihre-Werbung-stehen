# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.5.6/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/2.5.6/maven-plugin/reference/html/#build-image)


# Own Notes

### Different Tests
#### h2
test -> application.properties
```
jdbc.driverClassName=org.h2.Driver
jdbc.url=jdbc:h2:mem:myDb;DB_CLOSE_DELAY=-1;NON_KEYWORDS=KEY,VALUE
```

AddressbookAddressDAOTests
```
@Autowired
public AddressDAO_Database address;
```

#### mysql
test -> application.properties
```
jdbc.driverClassName=com.mysql.cj.jdbc.Driver
jdbc.url=jdbc:mysql://localhost:3310/adresses?useSSL=FALSE&allowPublicKeyRetrieval=TRUE
```

run mysql in docker
```
docker run --name mysql-addressbook -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=adresses -d -p 3310:3306 mysql
```

AddressbookAddressDAOTests
```
@Autowired
public AddressDAO_Database address;
```

#### _memory
AddressbookAddressDAOTests
```
@Autowired
public AddressDAO_Memory address;
```

### TestInstance
You can think of this as the static version of a test:
Creates only **one** test-instance per test.

### Docker run
docker run --name mysql-addressbook -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=adresses -d -p 3310:3306 mysql

### First Attempt
1. pom.xml
""
<dependency>
<groupId>mysql</groupId>
<artifactId>mysql-connector-java</artifactId>
<version>8.0.11</version>
</dependency>
""

2. Delete AddressDAO_Memory.java
3. docker run --name mysql-addressbook -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=adresses -d -p 3310:3306 mysql
4. AdderssDAO_Database.java Zeile 20
""
connection = DriverManager.getConnection("jdbc:mysql://localhost:3310/adresses?useSSL=FALSE","root","root");
""

### Changes
#### pom.xml
Needs some dependencies to get to run (look above at "First Attempt").

Especially Database connectors:
- mysql
- h2

#### FirstnameLastnameDatecomparator
Made Classname more specific.

Unknown what to compare (currently compares registrationDates)


## Problems
### Can't Start Program (Main not found)
Deploy the Program via Maven.
![Picture of Maven Panel with deploy](./res/Problem_cannot_run.png)
Afterwards try running the Main Function again.

