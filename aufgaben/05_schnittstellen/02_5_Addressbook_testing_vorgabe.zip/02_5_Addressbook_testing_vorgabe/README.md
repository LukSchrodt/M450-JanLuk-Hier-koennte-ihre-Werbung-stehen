# Setup

1. Download This Java Application
2. Open in IntelliJ
3. 